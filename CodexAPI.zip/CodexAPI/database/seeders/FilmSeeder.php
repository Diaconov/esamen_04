<?php

namespace Database\Seeders;

use App\Models\Film;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class FilmSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Film::create([
            "idFilm" => 1,
            "titolo" => "The Fast and the Furious: Tokyo Drift",
            "durata" => 86.4,
            "regista" => "Justin Lin",
            "categoria" => "azione",
            "anno" => 2006,
            "trama" => "Shaun Boswell è un ragazzo irrequieto al quale piace partecipare alle corse di auto clandestine. Finito nei guai con la giustizia, è costretto, per evitare la prigione, a raggiungere suo padre che è militare in servizio a Tokyo.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Film::create([
            "idFilm" => 2,
            "titolo" => "Deadpool",
            "durata" => 154.8,
            "regista" => "Fabian Nicieza",
            "categoria" => "Avventura",
            "anno" => 2014,
            "trama" => "È un eroe-antieroe noto per il suo humour, fatto di doppisensi e riferimenti a film, serie televisive, canzoni e immagini popolari. Teledipendente tanto da descrivere la propria mano destra come La mia mano CINEMAX.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Film::create([
            "idFilm" => 3,
            "titolo" => "GHOST DOG",
            "durata" => 84,
            "regista" => "Jim Jarmusch",
            "categoria" => "Azione",
            "anno" => 1999,
            "trama" => "Ghost Dog è il soprannome di un sicario, che vive solitario in una sporca terrazza del New Jersey, seguendo i precetti del Bushido, il codice di comportamento del samurai.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);
    }
}
