<?php

namespace Database\Seeders;

use App\Models\Episodio;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EpisodiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Episodio::create([
            "serieTv" => "Dark",
            "titolo" => "Segreti",

            "durata" => 60,
            "stagione" => 1,
            "episodio" => 1,
            "anno" => 2017,
            "trama" => "Jonas scopre inoltre che la ragazza di cui è da tempo innamorato, Martha Nielsen, ora sta con il suo migliore amico, Bartosz Tiedemann.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Episodio::create([
            "serieTv" => "Dark",
            "titolo" => "Bugie",

            "durata" => 60,
            "stagione" => 1,
            "episodio" => 2,
            "anno" => 2017,
            "trama" => "La scomparsa di Mikkel riporta i cittadini di Winden indietro nel tempo, precisamente ai fatti accaduti nel 1986",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Episodio::create([
            "serieTv" => "Breaking Bad",
            "titolo" => "Questione di chimica",
            "durata" => 60,
            "stagione" => 1,
            "episodio" => 1,
            "anno" => 2008,
            "trama" => "In una riserva indiana nel deserto del New Mexico, un uomo in mutande e maschera antigas guida con difficoltà un camper.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Episodio::create([
            "serieTv" => "Breaking Bad",
            "titolo" => "Senza ritorno",
            "durata" => 60,
            "stagione" => 1,
            "episodio" => 2,
            "anno" => 2008,
            "trama" => "Jesse e non vedersi mai più dopo che si saranno sbarazzati dei corpi.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Episodio::create([
            "serieTv" => "How I Met Your Mother",
            "titolo" => "Una lunga storia",
            "durata" => 22,
            "stagione" => 1,
            "episodio" => 1,
            "anno" => 2008,
            "trama" => "Quando il suo migliore amico Marshall si fidanza, Ted capisce che è giunto anche per lui il momento di trovare la sua anima gemella.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        Episodio::create([
            "serieTv" => "How I Met Your Mother",
            "titolo" => "La giraffa viola",
            "durata" => 22,
            "stagione" => 1,
            "episodio" => 2,
            "anno" => 2008,
            "trama" => "Dopo il disastro del loro primo incontro, Ted cerca disperatamente di ottenere un secondo appuntamento con Robin.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);
    }
}
