<?php

namespace Database\Seeders;

use App\Models\SerieTv;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SerieTvSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        SerieTv::create([
            "titolo" => "Dark",
            "durata" => 45.00,
            "stagioni" => 3,
            "episodi" => 28,
            "regista" => "Baran bo Odar",
            "categoria" => "Horror",
            "anno" => "2017",
            "trama" => "Baran Odar (Olten, 18 aprile 1978) è uno sceneggiatore e regista svizzero naturalizzato tedesco, principalmente conosciuto per aver diretto e co-creato le serie Netflix Dark e 1899.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        SerieTv::create([
            "titolo" => "Breaking Bad",
            "durata" => 42,
            "stagioni" => 5,
            "episodi" => 62,
            "regista" => "Vince Gilligan",
            "categoria" => "Horror",
            "anno" => 2008,
            "trama" => "George Vincent Vince Gilligan Jr. (Richmond, 10 febbraio 1967) è uno sceneggiatore, regista e produttore televisivo statunitense, noto soprattutto per aver ideato la serie televisiva Breaking Bad e il suo spin-off Better Call Saul.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);

        SerieTv::create([
            "titolo" => "How i met your mother",
            "durata" => 20,
            "stagioni" => 9,
            "episodi" => 208,
            "regista" => "Pamela Fryman",
            "categoria" => "Sitcom",
            "anno" => 2005,
            "trama" => "Nell'anno 2030 Ted Mosby, un affermato architetto, inizia a raccontare ai suoi due figli gli eventi che, a partire da venticinque anni prima, lo hanno portato a conoscere quella che sarebbe diventata la sua futura moglie e loro madre.",
            "fotoAnteprima" => null,
            "trailer" => null,
        ]);
    }
}
