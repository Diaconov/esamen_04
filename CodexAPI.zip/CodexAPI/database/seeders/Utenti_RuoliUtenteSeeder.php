<?php

namespace Database\Seeders;

use App\Models\utente_ruoloUtente;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class Utenti_RuoliUtenteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        utente_ruoloUtente::create(["idUtente" => 1, "idRuoloUtente" => 1]);
        utente_ruoloUtente::create(["idUtente" => 1, "idRuoloUtente" => 2]);
    }
}
