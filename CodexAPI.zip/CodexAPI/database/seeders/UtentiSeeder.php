<?php

namespace Database\Seeders;

use App\Models\Utente;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UtentiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Utente::create([
            "nome" => "Slavic",
            "cognome" => "Diaconov",
            "sesso" => 1,
            "idStato" => 1,
            "idRuoloUtente" => "1",
            "cittadinanza" => "Mda",
            "dataNascita" => "1997-04-15",
            "credito" => 0,
            "codiceFiscale" => hash("sha512", trim("DCNVSL97D15Z140W")),
        ]);

        Utente::create([
            "nome" => "Maria",
            "cognome" => "Morosanu",
            "sesso" => 2,
            "idStato" => 1,
            "idRuoloUtente" => "2",
            "cittadinanza" => "Mda",
            "dataNascita" => "1996-05-27",
            "credito" => 100,
            "codiceFiscale" => hash("sha512", trim("MRSNML96D27Z150W")),
        ]);
    }
}
